import { createRouter, createWebHistory } from 'vue-router';
import Home from '../views/Home.vue';
import QtTutorial from '../views/QtTutorial.vue';
import AdminDashboard from '../views/admin/Dashboard.vue';

const routes = [
  { path: '/', component: Home },
  { path: '/qt', component: QtTutorial },  // 像图片的 Qt 页面
  { path: '/admin', component: AdminDashboard, meta: { requiresAuth: true } },  // 后台
];

const router = createRouter({ history: createWebHistory(), routes });
export default router;
