<template>
  <el-container style="height: 100vh;">
    <el-header>
      <el-menu
        :default-active="activeIndex"
        mode="horizontal"
        @select="handleSelect"
      >
        <el-menu-item index="/">首页</el-menu-item>
        <el-menu-item index="/qt">Qt 教程</el-menu-item>
        <!--<el-menu-item index="/data-structure">数据结构</el-menu-item>-->
        <!-- 后面加更多分类 -->
        <el-menu-item index="/admin">后台管理</el-menu-item>
      </el-menu>
    </el-header>
    <el-main>
      <router-view></router-view> <!-- 这里显示页面内容 -->
    </el-main>
    <el-footer>© 你的名字 | 知识分享 | 文章总数: xx | 字数: xx</el-footer>
  </el-container>
</template>


<script setup>
import { computed } from 'vue'
import { useRouter, useRoute } from 'vue-router'

const router = useRouter()
const route = useRoute()

const activeIndex = computed(() => route.path || '/')

const handleSelect = (key) => {
  router.push(key)
}
</script>


























































































































































































