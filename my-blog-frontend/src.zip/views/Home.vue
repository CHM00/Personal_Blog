<template>
  <el-row :gutter="20">
    <el-col :span="18">
      <h2>最新/热门文章</h2>
      <el-card v-for="item in articles" :key="item.id" style="margin-bottom: 20px;">
        <h3>{{ item.title }}</h3>
        <p>发布时间: {{ item.date }} | 标签: <el-tag v-for="tag in item.tags" :key="tag">{{ tag }}</el-tag></p>
        <p>摘要: {{ item.summary }}</p>
      </el-card>
    </el-col>
    <el-col :span="6">
      <el-card>
        <h4>公告</h4>
        <p>今天又是被好运砸中的一天～</p>
      </el-card>
      <el-card style="margin-top: 20px;">
        <h4>公众号 / 微信</h4>
        <p>扫码关注获取最新文章</p>
      </el-card>
    </el-col>
  </el-row>
</template>

<script setup>
// 临时假数据，后面连后端替换
const articles = [
  { id: 1, title: 'Qt 入门', date: '2025-01-01', tags: ['Qt', 'C++'], summary: 'Qt 基础知识介绍...' },
  // 加更多
]
</script>





























